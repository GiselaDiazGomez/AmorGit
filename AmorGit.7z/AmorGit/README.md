# AmorGit
Se ingresan dos nombres y se muestran en página.
